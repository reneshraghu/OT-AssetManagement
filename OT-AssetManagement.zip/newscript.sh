#!/bin/bash

# Input file containing target IP addresses
INPUT_FILE="ips.txt"

# Check if the input file exists
if [[ ! -f "$INPUT_FILE" ]]; then
  echo "Error: Input file $INPUT_FILE not found!"
  exit 1
fi

# Iterate through each IP address in the input file
while IFS= read -r TARGET_IP; do
  if [[ -z "$TARGET_IP" ]]; then
    continue  # Skip empty lines
  fi

  echo "Scanning $TARGET_IP..."

  # BACnet-discover-enumerate
  nmap --script ./BACnet-discover-enumerate.nse -p 47808 -oX "BACnet-discover-enumerate_$TARGET_IP.xml" $TARGET_IP

  # EtherNet/IP Information
  nmap --script ./enip-info.nse -p 44818 -oX "enip-info_$TARGET_IP.xml" $TARGET_IP

  # MMS Queries
  nmap --script ./mmsQueries.lua -p 102 -oX "mmsQueries_$TARGET_IP.xml" $TARGET_IP

  # Foxboro/Invensys DCS FoxApi
  nmap -sU --script ./fox-info.nse -p 55555 -oX "fox-info_udp_$TARGET_IP.xml" $TARGET_IP
  nmap --script ./fox-info.nse -p 55555 -oX "fox-info_tcp_$TARGET_IP.xml" $TARGET_IP

  # Modicon (Modbus)
  nmap --script ./modicon-info.nse -p 502 -oX "modicon-info_$TARGET_IP.xml" $TARGET_IP

  # Profinet PNIO Discovery
  nmap --script ./Profinet-dce-rpc-pnio.nse -p 34962 -oX "Profinet-dce-rpc-pnio_$TARGET_IP.xml" $TARGET_IP

  # HART-IP Information
  nmap -sU --script ./hartip-info.nse -p 5094 -oX "hartip-info_$TARGET_IP.xml" $TARGET_IP

  # IEC 61850 MMS
  nmap --script ./iec61850_mms.nse -p 1755 -oX "iec61850_mms_$TARGET_IP.xml" $TARGET_IP

  # PC Worx
  nmap --script ./pcworx-info.nse -p 1962 -oX "pcworx-info_$TARGET_IP.xml" $TARGET_IP

  # MELSEC-Q UDP Discover
  nmap -sU --script ./melsecq-discover-udp.nse -p 8192 -oX "melsecq-discover-udp_$TARGET_IP.xml" $TARGET_IP

  # ProConOS Information
  nmap --script ./proconos-info.nse -p 20547 -oX "proconos-info_$TARGET_IP.xml" $TARGET_IP

  # CODESYS v2 Discovery
  nmap --script ./codesys-v2-discover.nse -p 2455 -oX "codesys-v2-discover_$TARGET_IP.xml" $TARGET_IP

  # DNP3 Information
  nmap --script ./dnp3-info.nse -p 20000 -oX "dnp3-info_$TARGET_IP.xml" $TARGET_IP

  # ENIP Enumerate
  nmap --script ./enip-enumerate.nse -p 44818 -oX "enip-enumerate_$TARGET_IP.xml" $TARGET_IP

  # S7 Communication on Siemens Systems
  nmap --script ./s7-enumerate.nse -p 102 -oX "s7-enumerate_$TARGET_IP.xml" $TARGET_IP

  # KNXnet/IP
  nmap --script ./knx-gateway-discover -p 3671 -oX "KNXnet-IP_$TARGET_IP.xml" $TARGET_IP

done < "$INPUT_FILE"

echo "Scanning complete."
